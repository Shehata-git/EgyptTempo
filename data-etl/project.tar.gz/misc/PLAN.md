Act as a Senior ML Data Engineer. I am handing off a 10-year Spatio-Temporal climate dataset (stored in a MongoDB cluster) to a DL team using Google Colab.

CRITICAL CONSTRAINTS:

1. Colab has a strict 12GB RAM limit. Google Drive has severe FUSEBLK I/O bottlenecks.
2. We must process data in 365-day (yearly) chunks locally.
3. The workflow MUST be: MongoDB -> RAM -> Local SSD -> Tarball -> Google Drive.

Write the following SIX meticulously detailed, strictly separated files. Do not merge them.

### FILE 1: `1_fetch_and_scale.py` (MongoDB to Scaled Arrays)

Write a Python script that:

- Uses `argparse` to accept a `--year` argument.
- Connects to MongoDB via PyMongo and queries only that specific year.
- Extracts the spatial grid, applies Min-Max normalization in RAM, and saves the global `scaler_params.npy` to Colab's local disk (`/content/local_staging/`).
- Saves the scaled but un-windowed data as `raw_scaled_year.npy` to the local staging directory.
- Deletes variables and calls `gc.collect()`.

### FILE 2: `2_build_tensors.py` (Sliding Windows)

Write a Python script that:

- Uses `argparse` to accept a `--year` argument.
- Loads `raw_scaled_year.npy` from `/content/local_staging/` into RAM.
- Builds the ConvLSTM sliding window tensors (X: 14-day lookback, y: 1-day target) and injects the `channel` dimension.
- Saves the final `X_year.npy` and `y_year.npy` to `/content/local_staging/`.
- Deletes `raw_scaled_year.npy` from the disk to free space, deletes variables, and calls `gc.collect()`.

### FILE 3: `3_pack_and_move.py` (Tarball and Drive Transfer)

Write a Python script that:

- Uses `argparse` to accept a `--year` argument.
- Uses `tarfile` to compress the contents of `/content/local_staging/` into a single `climate_tensors_<year>.tar.gz` archive entirely on Colab's local disk.
- Uses `shutil.move` to transfer that `.tar.gz` archive to `/content/drive/MyDrive/Climate_Tensors/`.
- Runs `rm -rf /content/local_staging/*` to completely clear the local SSD for the next year.

### FILE 4: `run_pipeline.sh` (The Bash Orchestrator)

Write a Bash script that loops through the years (e.g., 2014 to 2023). For each year, it sequentially executes:

1. `python 1_fetch_and_scale.py --year $Y`
2. `python 2_build_tensors.py --year $Y`
3. `python 3_pack_and_move.py --year $Y`
Include error handling to stop the loop if any script fails.

### FILE 5: `consumer_ingestion.md` (Colab Cells for DL Team)

Write the Markdown/Bash cells the Deep Learning team needs to run in their notebook:

- Cell 1: Mount Google Drive.
- Cell 2: Bash loop to copy the yearly `.tar.gz` files from Drive back to their local `/content/data/` disk, and untar them locally. Include a warning that reading directly from Drive causes I/O bottlenecks.

### FILE 6: `consumer_dataloader.py` (PyTorch Lazy Loader)

Write a PyTorch script for the DL team containing:

- A custom `Dataset` class designed to lazy-load the locally extracted `.npy` files batch-by-batch during `__getitem__`. It CANNOT load all files into RAM at initialization.
- A standard PyTorch `DataLoader` setup.
